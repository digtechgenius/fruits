package com.fruit.utils

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.fruit.data.Fruit
import org.junit.Rule


abstract class BaseTestFruitApp {
    @get:Rule
    var coroutineTestRule = MainCoroutineRule()

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()
    var list = listOf(
        Fruit(
            "Apple", 10,20),
        Fruit(
            "Oranges", 10,20),
        Fruit(
            "Banana", 10,20),
        Fruit(
            "Grapes", 10,20),
    )
}