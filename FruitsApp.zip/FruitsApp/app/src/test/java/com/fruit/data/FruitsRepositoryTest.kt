package com.fruit.data

import com.fruit.utils.BaseTestFruitApp
import com.fruit.utils.DataResponse
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runBlockingTest
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner
import retrofit2.Response


@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class FruitsRepositoryTest : BaseTestFruitApp() {

    private lateinit var fruitRepository: FruitsRepository

    private lateinit var fruitApiServiceMock: FruitApiService

    private var retroResponse = FruitList(list)
    private var response = Response.success(retroResponse)

    @Before
    fun setup() {
        fruitApiServiceMock = Mockito.mock(FruitApiService::class.java)
        fruitRepository = FruitsRepository(fruitApiServiceMock)
    }

    private fun generateMockResponse(success: Boolean, retroResponse: FruitList): Response<FruitList> {
        response = if (success){
            Response.success(retroResponse)
        }else{
            Response.error(
                400,
                "{\"key\":[\"Some error\"]}"
                    .toResponseBody("application/json".toMediaTypeOrNull())
            )
        }
        return response
    }

    @Test
    fun tesHappyPath() {

        coroutineTestRule.testDispatcher.runBlockingTest {
            //Setup-Given
            Mockito.`when`(fruitApiServiceMock.getFruitsList()).thenReturn(
                generateMockResponse(true,retroResponse)
            )
            // Execute-When
            val listFlow = fruitRepository.getFruitsList().toList()

            //Verify-Then
            assertThat(listFlow).isEqualTo(listOf(DataResponse.Loading, DataResponse.Success(list)))
        }
    }


    @Test
    fun testUnhappyPath() {

        coroutineTestRule.testDispatcher.runBlockingTest {
            //Setup-Given
            Mockito.`when`(fruitApiServiceMock.getFruitsList()).thenReturn(
                generateMockResponse(false,retroResponse)
            )
            // Execute-When
            val listFlow = fruitRepository.getFruitsList().toList()

            //Verify-Then
            assertThat(listFlow).isEqualTo(listOf(DataResponse.Loading, DataResponse.Error()))
        }
    }

}