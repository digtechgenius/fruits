package com.fruit.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fruit.utils.AppConstants.FRUITS_EMPTY_MESSAGE
import com.fruit.utils.DataResponse
import com.fruit.data.Fruit
import com.fruit.utils.AppConstants.STANDARD_ERROR_MESSAGE


// Fav City List Screen ( Compound Component)

@Composable
fun FruitList(uiTimer: () -> Unit,
              uiState: DataResponse<List<Fruit>>,
              onNavigateToFruitDetailScreen: (Fruit) -> Unit,
){

    Box(modifier = Modifier
        .background(color = MaterialTheme.colors.surface)
        .fillMaxHeight()
    ) {

        when (uiState) {
            is DataResponse.Loading -> {
                CircularProgressBar(true)
            }
            is DataResponse.Success -> {

                if(uiState.data.isNullOrEmpty()){

                    ErrorMessage(message = FRUITS_EMPTY_MESSAGE)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        items(items = uiState.data, itemContent = { item ->
                            CityListCardView(item.type, onClick = {
                                onNavigateToFruitDetailScreen(item)
                            })
                        })
                    }

                }
                SideEffect {
                    uiTimer()
                }
            }
            is DataResponse.Error -> {
                SideEffect {
                    uiTimer()
                }
                ErrorMessage(STANDARD_ERROR_MESSAGE )
            }
        }
    }
}




