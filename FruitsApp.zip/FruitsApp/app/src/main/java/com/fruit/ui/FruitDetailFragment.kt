package com.fruit.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material.Scaffold
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.fruit.data.Fruit
import com.fruit.ui.components.FruitDetailView
import com.fruit.ui.theme.AppTheme
import dagger.hilt.android.AndroidEntryPoint

@ExperimentalFoundationApi
@ExperimentalComposeUiApi
@AndroidEntryPoint
class FruitDetailFragment : Fragment() {

    private val fruitsViewModels by activityViewModels<FruitsViewModel>()
    lateinit var fruit: Fruit

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.getParcelable<Fruit>("fruit")?.let {
            fruit = it
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                AppTheme(
                    content =
                    {
                        Scaffold {
                            FruitDetailView(
                                {
                                    fruitsViewModels.sendUIStats()
                                },
                                fruit
                            )
                        }
                    }
                )
            }
        }
    }
}








