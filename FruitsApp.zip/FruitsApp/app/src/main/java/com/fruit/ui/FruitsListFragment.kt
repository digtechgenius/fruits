package com.fruit.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.material.Scaffold
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.findNavController
import com.fruit.R
import com.fruit.ui.components.FruitList
import com.fruit.ui.theme.AppTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * A simple [Fragment] to show list of fruits
 */
@ExperimentalFoundationApi
@ExperimentalComposeUiApi
@AndroidEntryPoint
class FruitsListFragment : Fragment() {

    private val fruitsViewModels by activityViewModels<FruitsViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            fruitsViewModels.favCitiesLiveDataRead.observe(viewLifecycleOwner, { uiState ->
                run {
                    setContent {
                        AppTheme(
                            content =
                            {
                                Scaffold {
                                    FruitList(
                                        uiTimer= {fruitsViewModels.sendUIStats()},
                                        uiState = uiState,
                                        onNavigateToFruitDetailScreen = {
                                            fruitsViewModels.startUITimer()
                                            val bundle = Bundle()
                                            bundle.putParcelable("fruit", it)
                                            findNavController().navigate(
                                                R.id.FruitDetailFragment,
                                                bundle
                                            )
                                        }
                                    )
                                }
                            }
                        )
                    }
                }
            }
            )
        }
    }
}