package com.fruit.data

import com.fruit.utils.DataResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject


class FruitsRepository @Inject constructor(
    private val remoteDataSource: FruitApiService,

) : IFruitsRepository {
    override var apiLoadTimer: Long = 0
    override var apiError: String? = null

    override suspend fun getFruitsList(): Flow<DataResponse<List<Fruit>>> {
        return flow  {
            // api handle Initialize
            emit(DataResponse.Loading)
            apiLoadTimer = System.currentTimeMillis()
            apiError = null

            try {
                val response =
                    remoteDataSource.getFruitsList()
                if (response.isSuccessful) { // api Success case

                    response.body()?.let {
                        if(it.fruit.isNullOrEmpty()) apiError = "Fruit List Empty"
                        emit(DataResponse.Success(it.fruit)) // api Success valid body case
                    } ?: run {
                        emit(DataResponse.Error("Response Body Empty"))  // api Success  body empty case
                        apiError = "Response Body Empty"
                    }

                } else {
                    emit(DataResponse.Error())  // api call fail case
                    apiError = "Api Call fails"
                }
            } catch (ex: Exception) {
                emit(DataResponse.Error())  // network fail or parse exemption
                apiError = "Api Ex " + ex.localizedMessage
            }
            prepareApiStatsData()
        }
    }

    override suspend fun prepareApiStatsData() {
        apiLoadTimer = (System.currentTimeMillis() - apiLoadTimer)
        apiError?.let {
            uploadStatData("error", it)  // api failure case
        } ?: (
           uploadStatData("load", apiLoadTimer.toString())) // api success case
    }

    override suspend fun uploadStatData(event: String, data: String) {
        try {
            val response =
                remoteDataSource.sendStats(event, data)
          // Failure case to be implemented as the per requirement
            // Ideally with the WorkManager job. Out of Scope for Current assignment specification
        } catch (ex: Exception) {
            // Failure case to be implemented as the per requirement
            // Ideally with the WorkManager job. Out of Scope for Current assignment specification
        }
    }
}