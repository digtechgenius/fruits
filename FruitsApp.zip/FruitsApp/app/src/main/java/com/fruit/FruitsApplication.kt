package com.fruit

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class FruitsApplication : Application()