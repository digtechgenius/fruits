package com.fruit.data

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query


interface FruitApiService {


    @GET("data.json")
    suspend fun getFruitsList(): Response<FruitList>

    @GET("stats")
    suspend fun sendStats(
        @Query("event") event: String,
        @Query("data") data: String,
    ): Response<Unit>

}
