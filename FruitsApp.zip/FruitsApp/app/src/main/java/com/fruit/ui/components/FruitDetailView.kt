package com.fruit.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fruit.data.Fruit
import com.fruit.utils.UnitsConvert.gramsToKg
import com.fruit.utils.UnitsConvert.pensToPounds


// Fruit Screen View (Compound Component)
@ExperimentalFoundationApi
@Composable
fun FruitDetailView(uiTimer: () -> Unit,fruit: Fruit) {

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text =  "Fruit: ${fruit.type}", style = MaterialTheme.typography.h1)
        Spacer(modifier = Modifier.height(30.dp))
        Text(text = "Weight (Kg): ${gramsToKg(fruit.weight)}", style = MaterialTheme.typography.h2)
        Spacer(modifier = Modifier.height(20.dp))
        Text(text = "Price (£): ${pensToPounds(fruit.price)}", style = MaterialTheme.typography.h2)
        Spacer(modifier = Modifier.height(10.dp))
    }
    SideEffect {
        uiTimer()
    }
}