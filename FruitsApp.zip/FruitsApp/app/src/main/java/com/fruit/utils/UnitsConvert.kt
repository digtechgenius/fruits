package com.fruit.utils

object UnitsConvert {

    fun gramsToKg(weight : Int): String {
        return if(weight != -1) {
            ((weight.toDouble()/1000)).toString()
        } else {
            "Not available"
        }
    }

    fun pensToPounds(price : Int): String {
        return  if(price != -1) {
            ((price.toDouble()/100)).toString()
        } else {
            "Not available"
        }
    }
}