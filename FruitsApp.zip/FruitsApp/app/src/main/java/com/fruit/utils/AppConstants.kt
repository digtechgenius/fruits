package com.fruit.utils


// Application Wide Constants are placed here
object AppConstants {
    const val TIMER_INIT : Long = 0
    const val BASE_URL = "https://raw.githubusercontent.com/fmtvp/recruit-test-data/master/"
    const val STANDARD_ERROR_MESSAGE: String =
        "OOPS! Error \n Please check your internet and data" // This can be replaced from CMS
    const val FRUITS_EMPTY_MESSAGE: String =
        "Empty Fruit List"
}


