package com.fruit.ui

import androidx.lifecycle.*
import com.fruit.utils.AppConstants.TIMER_INIT
import com.fruit.utils.DataResponse
import com.fruit.data.Fruit
import com.fruit.data.FruitsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class FruitsViewModel @Inject constructor(
   private val repository: FruitsRepository,
) : ViewModel() {

     private  var  screenTimer: Long = TIMER_INIT

    private var favCitiesLiveData: LiveData<DataResponse<List<Fruit>>> = MutableLiveData()

    val favCitiesLiveDataRead: LiveData<DataResponse<List<Fruit>>>
        get() = favCitiesLiveData

    init {
        viewModelScope.launch {
            startUITimer()
            favCitiesLiveData = repository.getFruitsList().asLiveData(viewModelScope.coroutineContext)
        }
    }

    fun startUITimer(){
        screenTimer =  System.currentTimeMillis()
    }

    fun sendUIStats(){
        if(!screenTimer.equals(TIMER_INIT)) {
            viewModelScope.launch {
                screenTimer = System.currentTimeMillis() - screenTimer
                repository.uploadStatData("display", screenTimer.toString())
                screenTimer = TIMER_INIT
            }
        }
    }
}