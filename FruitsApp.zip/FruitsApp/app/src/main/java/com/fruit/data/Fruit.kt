package com.fruit.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Fruit(val type: String,val price: Int = -1,val weight: Int = -1) : Parcelable

@Parcelize
data class FruitList(val fruit: List<Fruit> ) : Parcelable