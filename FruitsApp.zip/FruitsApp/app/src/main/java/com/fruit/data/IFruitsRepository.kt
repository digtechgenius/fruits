package com.fruit.data

import com.fruit.utils.DataResponse
import kotlinx.coroutines.flow.Flow

interface IFruitsRepository {
    var apiLoadTimer: Long
    var apiError: String?

    suspend fun getFruitsList(): Flow<DataResponse<List<Fruit>>>

    suspend fun prepareApiStatsData()

    suspend fun uploadStatData(event: String, data: String)
}